# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

import threading
from time import sleep

from resources.lib.proxyserver import ProxyServer
from resources.lib.utils import ProxyHelper, WebException
from resources.lib.webcalls import LoginSession

class TestProxyServer:
    # def __init__(self, websession):
    #     super().__init__(websession)
    #     self.lock = threading.Lock()
    #     self.port = 6868
    #     self.address = '127.0.0.1'
    #     websession.session.printNetworkTraffic = True
    #     self.helper = ProxyHelper(websession.addon)

    def test_start_proxy(self, websession):
        websession.do_login()
        thread = None
        proxyServer = None
        lock = threading.Lock()
        try:
            proxyServer = ProxyServer(websession.addon, ('127.0.0.1', 6868), lock)
            thread = threading.Thread(target=proxyServer.serve_forever)
            thread.start()
            sleep(1)
            rslt = ProxyHelper(websession.addon).dynamic_call(LoginSession.login, username='bad', password='bad')
            print(rslt)
            sleep(1)
            proxyServer.shutdown()
            thread.join()
            print('ProxyServer stopped')

        except IOError as e:
            print('Exception during ProxyServer test: {0}'.format(e))
        except WebException as e:
            print('Web Exception during ProxyServer test: {0}'.format(e))
            print('Message: {0}'.format(e.response))
            print('Status: {0}'.format(e.status))
            if proxyServer is not None:
                proxyServer.shutdown()
            if thread is not None:
                thread.join()
            print('ProxyServer stopped')

    def test_dynamic_call(self, websession):
        websession.do_login()
        thread = None
        proxyServer = None
        lock = threading.Lock()
        try:
            proxyServer = ProxyServer(websession.addon, ('127.0.0.1', 6868), lock)
            thread = threading.Thread(target=proxyServer.serve_forever)
            thread.start()
            sleep(1)
            events = []
            shows = ['crid:~~2F~~2Fgn.tv~~2F26434552~~2FSH041927000000']
            channelId = 'NL_000001_019401'
            rslt = ProxyHelper(websession.addon).dynamic_call(LoginSession.delete_recordings,
                                            events=events,
                                            shows=shows,
                                            channelId=channelId)
            print(rslt)
            sleep(1)
            proxyServer.shutdown()
            thread.join()
            print('ProxyServer stopped')

        except IOError as e:
            print('Exception during ProxyServer test: {0}'.format(e))
        except WebException as e:
            print('Web Exception during ProxyServer test: {0}'.format(e))
            print('Message: {0}'.format(e.response))
            print('Status: {0}'.format(e.status))
            if proxyServer is not None:
                proxyServer.shutdown()
            if thread is not None:
                thread.join()
            print('ProxyServer stopped')


# if __name__ == '__main__':
#     unittest.main()
