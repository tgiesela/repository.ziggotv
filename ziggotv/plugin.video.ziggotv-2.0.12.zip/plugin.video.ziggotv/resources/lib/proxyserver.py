"""
Proxy server related classes
"""
import base64
import pickle
import traceback
from urllib.parse import urlparse, parse_qs, unquote

import socket
import typing

import socketserver
import http.server

from http.server import BaseHTTPRequestHandler
from http.client import HTTPConnection
from http.client import HTTPSConnection

from xml.dom import minidom

import xbmc

from resources.lib.globals import CONST_BASE_HEADERS, G
from resources.lib.webcalls import LoginSession
from resources.lib.utils import WebException, SharedProperties

from resources.lib.avstream import StreamSession


class HTTPRequestHandler(BaseHTTPRequestHandler):
    """
    class to handle HTTP requests that arrive at the proxy server
    """
    def __init__(self, request, client_address: typing.Tuple[str, int], server: socketserver.BaseServer):
        # pylint: disable=useless-parent-delegation
        super().__init__(request, client_address, server)

    def log_request(self, code='-', size='-'):
        if code == 200:
            pass
        else:
            xbmc.log('HTTPRequestHandler log_request({0},{1})'.format(code, size), xbmc.LOGERROR)

    # pylint: disable=invalid-name
    def do_GET(self):
        """Handle http get requests, used for manifest and all streaming calls"""
        proxy: ProxyServer = self.server
        proxy.handle_get(self)

    def do_POST(self):
        """Handle http post requests, used for license"""
        proxy: ProxyServer = self.server
        proxy.handle_post(self)

    def do_OPTIONS(self):
        """
        Handle http OPTIONS
        @return:
        """
        proxy: ProxyServer = self.server
        proxy.handle_options(self)

    def do_HEAD(self):
        """
        Handle http HEAD
        @return:
        """
        proxy: ProxyServer = self.server
        proxy.handle_head(self)
    # pylint: enable=invalid-name


class ProxyServer(http.server.ThreadingHTTPServer):
    """
        Proxyserver for processing license and manifest request.
        Contains some functions to maintain state because HttpRequestHandler is instantiated
        for every new call
    """

    # pylint: disable=too-many-instance-attributes
    def __init__(self, addon, server_address, lock):
        http.server.ThreadingHTTPServer.__init__(self, server_address, HTTPRequestHandler)
        self.lock = lock
        self.addon = addon
        self.session = LoginSession(self.addon)
        self.streamsession = StreamSession(self.session)
        self.home = SharedProperties(addon=self.addon)
        self.kodiMajorVersion = self.home.get_kodi_version_major()
        self.kodiMinorVersion = self.home.get_kodi_version_minor()
        self.connectionTimeout = self.addon.getSettingNumber('connection-timeout')
        self.uuId = SharedProperties(addon=self.addon).get_uuid()
        xbmc.log("ProxyServer created", xbmc.LOGINFO)

    def server_bind(self):
        super().server_bind()
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    def send_error(self, exc: Exception, request: HTTPRequestHandler):
        """
        Function to send an error message in case of a failure
        
        :param self: 
        :param exc: the exception that has occurred
        :type exc: Exception
        :param request: the http request which caused the error
        :type request: HTTPRequestHandler
        """
        try:
            xbmc.log(traceback.format_exc(), xbmc.LOGDEBUG)
            request.send_response(500)
            request.send_header('Content-Type','text/html')
            request.end_headers()
            request.wfile.write(bytes(str(exc), 'utf-8'))
        # pylint: disable=broad-exception-caught
        except Exception as ex:
            xbmc.log('Failed to send proper response: {0}'.format(ex))

    def handle_manifest(self, request: HTTPRequestHandler, requestType='get'):
        """
        Function to handle the manifest request. The url for the real host is constructed here. The
        parameters in the request (hostname, path and token) are extracted and the streaming token
        is inserted. The request is forwarded to the real host.
        @param request:
        @param requestType: 'get'|'head'
        @return:
        """
        parsedUrl = urlparse(request.path)
        qs = parse_qs(parsedUrl.query)
        if 'path' in qs and 'hostname' in qs and 'x-streaming-token' in request.headers:
            token = request.headers['x-streaming-token']
            stream = self.streamsession.find_stream(token)
            if stream is None:
                raise RuntimeError('Stream not found for token: {token}')
            manifestUrl = stream.get_manifest_url(proxyUrl=request.path)
            with self.lock:
                manifestBaseurl = None
                if requestType == 'get':
                    response = self.session.get_manifest(manifestUrl)
                    if response.status_code == 200:
                        manifestBaseurl = self.baseurl_from_manifest(response.content)
                elif requestType == 'head':
                    response = self.session.do_head(manifestUrl)
            stream.update_redirection(request.path, response.url, manifestBaseurl)
            request.send_response(response.status_code)
            # See wiki of InputStream Adaptive. Also depends on inputstream.adaptive.manifest_type. See listitemhelper.
            if self.kodiMajorVersion > 20:
                request.send_header('content-type', 'application/dash+xml')
            request.end_headers()
            request.wfile.write(response.content)

        else:
            request.send_response(404)
            request.end_headers()

    def handle_default(self, request: HTTPRequestHandler):
        # pylint: disable=too-many-locals, too-many-branches
        """
        Handles get requests which are not manifest/license request. This concerns the video/audio requests.
        Also here the url for the real host must be constructed and the streaming token must be inserted.
        @param request:
        @return:
        """
        if 'x-streaming-token' in request.headers:
            token = request.headers['x-streaming-token']
            stream = self.streamsession.find_stream(token)
            if stream is None:
                raise RuntimeError('Stream not found for token: {token}')
        else:
            request.send_response(500)
            request.send_header('Content-Type','text/html')
            request.end_headers()
            request.wfile.write(bytes('x-streaming-token missing', 'utf-8'))
            return

        url = stream.replace_baseurl(request.path, stream.latestToken)
        parsedDestUrl = urlparse(url)
        if parsedDestUrl.scheme == 'https':
            connection = HTTPSConnection(parsedDestUrl.hostname, timeout=self.connectionTimeout)
        else:
            connection = HTTPConnection(parsedDestUrl.hostname, timeout=self.connectionTimeout)
        connection.request("GET", parsedDestUrl.path)
        response = connection.getresponse()
        request.send_response(response.status)
        chunked = False
        for header in response.headers:
            if header.lower() == 'transfer-encoding':
                if response.headers[header].lower() == 'chunked':
                    #  We don't know the length upfront
                    chunked = True
            request.send_header(header, response.headers[header])
        request.end_headers()
        lenProcessed = 0
        if chunked:  # process the same chunks as received
            response.chunked = False
            blockLen = response.readline()
            length = int(blockLen, 16)
            while length > 0:
                lenProcessed += length
                block = response.read(length)
                blockToWrite = bytearray(blockLen)
                blockToWrite.extend(block + b'\r\n')
                request.wfile.write(blockToWrite)
                response.readline()
                blockLen = response.readline()
                length = int(blockLen, 16)
            blockToWrite = bytearray(blockLen)
            blockToWrite.extend(b'\r\n')
            request.wfile.write(blockToWrite)
        else:
            expectedLen = int(response.headers['Content-Length'])
            block = response.read(8192)
            while lenProcessed < expectedLen:
                lenProcessed += len(block)
                written = request.wfile.write(block)
                if written != len(block):
                    xbmc.log('count-written ({0})<>len(block)({1})'.format(written, len(block)))
                    return
                block = response.read(8192)

    def handle_get(self, request: HTTPRequestHandler):
        """
        General function to handle get requests
        @param request:
        @return:
        """
        path = request.path  # Path with parameters received from request e.g. "/manifest?id=234324"
        xbmc.log('HTTP GET Request received: {0}'.format(unquote(path)), xbmc.LOGDEBUG)
        try:
            if '/manifest' in path:
                self.handle_manifest(request)
            elif '/function' in path:
                self.handle_function(request)
            else:
                self.handle_default(request)

            xbmc.log('HTTP GET Request processed: {0}'.format(unquote(path)), xbmc.LOGDEBUG)
        except ConnectionResetError as exc:
            xbmc.log('Connection reset during processing: {0}'.format(exc), xbmc.LOGERROR)
            xbmc.log(traceback.format_exc(), xbmc.LOGDEBUG)
            request.close_connection = True
        except ConnectionAbortedError as exc:
            xbmc.log('Connection aborted during processing: {0}'.format(exc), xbmc.LOGERROR)
            xbmc.log(traceback.format_exc(), xbmc.LOGDEBUG)
            request.close_connection = True
        except BrokenPipeError as exc:
            xbmc.log('Connection lost during processing: {0}'.format(exc), xbmc.LOGERROR)
            xbmc.log(traceback.format_exc(), xbmc.LOGDEBUG)
            request.close_connection = True
        # pylint: disable=broad-exception-caught
        except Exception as exc:
            xbmc.log('Exception in handle_get(): {0}'.format(exc), xbmc.LOGERROR)
            self.send_error(exc, request)

    def handle_post(self, request: HTTPRequestHandler):
        # pylint: disable=too-many-locals, too-many-statements
        """
        Function to handle the license request. The request is forwarded to the real host.
        @param request:
        @return:
        """
        if 'x-streaming-token' in request.headers:
            token = request.headers['x-streaming-token']
            stream = self.streamsession.find_stream(token)
            if stream is None:
                raise RuntimeError('Stream not found for token: {0}'.format(token))
            token = stream.latestToken
        else:
            request.send_response(500)
            request.send_header('Content-Type','text/html')
            request.end_headers()
            request.wfile.write(bytes('x-streaming-token missing', 'utf-8'))
            return

        path = request.path  # Path with parameters received from request e.g. "/license?id=234324"
        xbmc.log('HTTP POST request received: {0}'.format(unquote(path)), xbmc.LOGDEBUG)
        if '/license' not in path:
            request.send_response(404)
            request.end_headers()
            return
        try:
            length = int(request.headers.get('content-length', 0))
            receivedData = request.rfile.read(length)

            parsedUrl = urlparse(request.path)
            contentId = parse_qs(parsedUrl.query)['ContentId'][0]

            licenseHeaders = dict(CONST_BASE_HEADERS)
            # 'Content-Type': 'application/octet-stream',
            licenseHeaders.update({
                'Host': G.ZIGGO_HOST,
                'x-streaming-token': token,
                'x-go-dev': self.uuId,
                'x-drm-schemeId': 'edef8ba9-79d6-4ace-a3c8-27dcd51d21ed',
                'deviceName': 'Firefox'
            })

            extraHeaders = self.session.get_extra_headers()
            for key, value in extraHeaders.items():
                licenseHeaders.update({key: value})

            hdrs = {}
            for key in request.headers: # Headers set by InputStream Adaptive (requesting license)
                hdrs[key] = request.headers[key]
            for key, value in licenseHeaders.items():  # Headers required for license request to work.
                hdrs[key] = value
            with self.lock:
                response = self.session.get_license(contentId, receivedData, hdrs)

            for key in response.headers:
                request.headers.add_header(key, response.headers[key])

            request.send_response(response.status_code)
            request.end_headers()
            request.wfile.write(response.content)
            xbmc.log('HTTP POST request processed: {0}'.format(unquote(path)), xbmc.LOGDEBUG)
        except ConnectionResetError as exc:
            xbmc.log('Connection reset during processing: {0}'.format(exc), xbmc.LOGERROR)
            xbmc.log(traceback.format_exc(), xbmc.LOGDEBUG)
            request.close_connection = True
        except ConnectionAbortedError as exc:
            xbmc.log('Connection aborted during processing: {0}'.format(exc), xbmc.LOGERROR)
            xbmc.log(traceback.format_exc(), xbmc.LOGDEBUG)
            request.close_connection = True
        except BrokenPipeError as exc:
            xbmc.log('Connection lost during processing: {0}'.format(exc), xbmc.LOGERROR)
            xbmc.log(traceback.format_exc(), xbmc.LOGDEBUG)
            request.close_connection = True
        # pylint: disable=broad-exception-caught
        except Exception as exc:
            xbmc.log('Exception in do_post(): {0}'.format(exc), xbmc.LOGERROR)
            self.send_error(exc, request)

    def handle_options(self, request: HTTPRequestHandler):
        # pylint: disable=too-many-statements
        """
        Handle http OPTIONS request. Just sends the headers. Is probably not used.
        @param request:
        @return:
        """
        try:
            request.send_response(200, "ok")
            request.send_header('Access-Control-Allow-Origin', '*')
            request.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
            request.send_header('access-control-allow-headers', 'Accept-Charset')
            request.send_header('access-control-allow-headers', 'Accept-Encoding')
            request.send_header('access-control-allow-headers', 'Access-Control-Request-Headers')
            request.send_header('access-control-allow-headers', 'Access-Control-Request-Method')
            request.send_header('access-control-allow-headers', 'Authorization')
            request.send_header('access-control-allow-headers', 'Cache-Control')
            request.send_header('access-control-allow-headers', 'Connection')
            request.send_header('access-control-allow-headers', 'Content-Encoding')
            request.send_header('access-control-allow-headers', 'Content-Type')
            request.send_header('access-control-allow-headers', 'Content-Length')
            request.send_header('access-control-allow-headers', 'Cookie')
            request.send_header('access-control-allow-headers', 'DNT')
            request.send_header('access-control-allow-headers', 'Date')
            request.send_header('access-control-allow-headers', 'Host')
            request.send_header('access-control-allow-headers', 'If-Modified-Since')
            request.send_header('access-control-allow-headers', 'Keep-Alive, Origin')
            request.send_header('access-control-allow-headers', 'Referer')
            request.send_header('access-control-allow-headers', 'Server')
            request.send_header('access-control-allow-headers', 'TokenIssueTime')
            request.send_header('access-control-allow-headers', 'Transfer-Encoding')
            request.send_header('access-control-allow-headers', 'User-Agent')
            request.send_header('access-control-allow-headers', 'Vary')
            request.send_header('access-control-allow-headers', 'X-CustomHeader')
            request.send_header('access-control-allow-headers', 'X-Requested-With')
            request.send_header('access-control-allow-headers', 'password')
            request.send_header('access-control-allow-headers', 'username')
            request.send_header('access-control-allow-headers', 'x-request-id')
            request.send_header('access-control-allow-headers', 'x-ratelimit-app')
            request.send_header('access-control-allow-headers', 'x-guest-token')
            request.send_header('access-control-allow-headers', 'X-HTTP-Method-Override')
            request.send_header('access-control-allow-headers', 'x-oesp-username')
            request.send_header('access-control-allow-headers', 'x-oesp-token')
            request.send_header('access-control-allow-headers', 'x-cus')
            request.send_header('access-control-allow-headers', 'x-dev')
            request.send_header('access-control-allow-headers', 'X-Client-Id')
            request.send_header('access-control-allow-headers', 'X-Device-Code')
            request.send_header('access-control-allow-headers', 'X-Language-Code')
            request.send_header('access-control-allow-headers', 'UserRole')
            request.send_header('access-control-allow-headers', 'x-session-id')
            request.send_header('access-control-allow-headers', 'x-entitlements-token')
            request.send_header('access-control-allow-headers', 'x-go-dev')
            request.send_header('access-control-allow-headers', 'x-profile')
            request.send_header('access-control-allow-headers', 'x-api-key')
            request.send_header('access-control-allow-headers', 'nv-authorizations')
            request.send_header('access-control-allow-headers', 'X-Viewer-Id')
            request.send_header('access-control-allow-headers', 'x-oesp-profile-id')
            request.send_header('access-control-allow-headers', 'x-streaming-token')
            request.send_header('access-control-allow-headers', 'x-streaming-token-refresh-interval')
            request.send_header('access-control-allow-headers', 'x-drm-device-id')
            request.send_header('access-control-allow-headers', 'x-profile-id')
            request.send_header('access-control-allow-headers', 'x-ui-language')
            request.send_header('access-control-allow-headers', 'deviceName')
            request.send_header('access-control-allow-headers', 'x-drm-schemeId')
            request.send_header('access-control-allow-headers', 'x-refresh-token')
            request.send_header('access-control-allow-headers', 'X-Username')
            request.send_header('access-control-allow-headers', 'Location')
            request.send_header('access-control-allow-headers', 'x-tracking-id')
            request.end_headers()
        except ConnectionResetError as exc:
            xbmc.log('Connection reset during processing: {0}'.format(exc), xbmc.LOGERROR)
            xbmc.log(traceback.format_exc(), xbmc.LOGDEBUG)
            request.close_connection = True
        except ConnectionAbortedError as exc:
            xbmc.log('Connection aborted during processing: {0}'.format(exc), xbmc.LOGERROR)
            xbmc.log(traceback.format_exc(), xbmc.LOGDEBUG)
            request.close_connection = True
        except BrokenPipeError as exc:
            xbmc.log('Connection lost during processing: {0}'.format(exc), xbmc.LOGERROR)
            xbmc.log(traceback.format_exc(), xbmc.LOGDEBUG)
            request.close_connection = True
        # pylint: disable=broad-exception-caught
        except Exception as exc:
            xbmc.log('Exception in handle_options(): {0}'.format(exc), xbmc.LOGERROR)
            self.send_error(exc, request)

    def handle_function(self, request: HTTPRequestHandler):
        """
        This function processes dynamic procedure calls via HTTP. Those requests are transformed into
        a call to LoginSession. This way only one LoginSession is kept alive and all access to ziggo-GO are
        via the http-proxy
        @param request:
        @return:
        """
        parsedUrl = urlparse(request.path)
        method = parsedUrl.path[10:]
        parts = method.split('.')
        calledclass = parts[0]
        calledmethod = parts[1]
        qs = parse_qs(parsedUrl.query)
        if 'args' in qs:
            args = pickle.loads(base64.b64decode(qs['args'][0]))
            try:
                retval = None
                xbmc.log(f'Called method: {calledclass}.{calledmethod} with args: {args}', xbmc.LOGDEBUG)
                if calledclass == self.session.__class__.__name__:
                    callableMethod = getattr(self.session, calledmethod)
                    with self.lock:
                        retval = callableMethod(**args)
                else:
                    if calledclass == self.streamsession.__class__.__name__:
                        callableMethod = getattr(self.streamsession, calledmethod)
                        xbmc.log(f'Calling StreamSession: {callableMethod} with args: {args}', xbmc.LOGDEBUG)
                        with self.lock:
                            retval = callableMethod(**args)
                request.send_response(200)
                if retval is None:
                    request.send_header('content-type', 'text/html')
                    request.end_headers()
                else:
                    request.send_header('content-type', 'application/octet-stream')
                    request.end_headers()
                    request.wfile.write(pickle.dumps(retval))
            except WebException as exc:
                request.send_response(exc.status)
                request.send_header('content-type', 'text/html')
                request.end_headers()
                request.wfile.write(exc.response)
        else:
            request.send_response(400)
            request.end_headers()

    def handle_head(self, request: HTTPRequestHandler):
        """
        when a HEAD request is received, it is assumed to be a manifest call. If so, it
        will be forwarded to the real host to get all the headers. Used occasionally by Input Stream Adaptive
        @param request:
        @return:
        """
        #  We should forward this to real server, but for now we will respond with code 501
        path = request.path  # Path with parameters received from request e.g. "/license?id=234324"
        xbmc.log('HTTP HEAD request received: {0}'.format(unquote(path)), xbmc.LOGDEBUG)
        try:
            if '/manifest' in path:
                self.handle_manifest(request, 'head')
            else:
                request.send_response(501)
                request.send_header('Content-Type','text/html')
                request.end_headers()
                request.wfile('/manifest missing')
        except ConnectionResetError as exc:
            xbmc.log('Connection reset during processing: {0}'.format(exc), xbmc.LOGERROR)
            xbmc.log(traceback.format_exc(), xbmc.LOGDEBUG)
            request.close_connection = True
        except ConnectionAbortedError as exc:
            xbmc.log('Connection aborted during processing: {0}'.format(exc), xbmc.LOGERROR)
            xbmc.log(traceback.format_exc(), xbmc.LOGDEBUG)
            request.close_connection = True
        except BrokenPipeError as exc:
            xbmc.log('Connection lost during processing: {0}'.format(exc), xbmc.LOGERROR)
            xbmc.log(traceback.format_exc(), xbmc.LOGDEBUG)
            request.close_connection = True
        # pylint: disable=broad-exception-caught
        except Exception as exc:
            xbmc.log('Exception in handle_head(): {0}'.format(exc), xbmc.LOGERROR)
            self.send_error(exc, request)

    @staticmethod
    def baseurl_from_manifest(manifest):
        """
        Function to check is a BaseURL exists in the manifest file. If so, extract and return it.
        This was required because some channels use relative url's (RTL8 and others).
        @param manifest:
        @return:
        """
        document = minidom.parseString(manifest)
        for parent in document.getElementsByTagName('MPD'):
            periods = parent.getElementsByTagName('Period')
            for period in periods:
                baseURL = period.getElementsByTagName('BaseURL')
                if baseURL.length == 0:
                    return None
                return baseURL[0].childNodes[0].data
        return None

    def run(self):
        """
        Function to initiate the thread
        """
        try:
            self.serve_forever(poll_interval=0.5)
        except KeyboardInterrupt as exc:
            xbmc.log('Exception in StopableHttpServer: {0}'.format(exc), xbmc.LOGERROR)
        finally:
            xbmc.log('Proxy server shutting down', xbmc.LOGINFO)
            self.server_close()
            xbmc.log('Proxy server closed', xbmc.LOGINFO)

    def stop(self):
        """
        Function to stop the proxyserver
        After shutdown is called a connection is made to the server to make sure it stops
        """
        self.shutdown()
        try:
            with socket.create_connection(self.server_address, timeout=1):
                pass
        # pylint: disable=broad-exception-caught
        except Exception:
            pass # Is expected here because the server is already down
